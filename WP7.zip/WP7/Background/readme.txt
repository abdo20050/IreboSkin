A simple customizable background

In the settings box type your desired width (in pixels), click SET, then type your Height and click Set. 
Notice how the background dimensions change after you clicked set.

You can customize the color and angle, here's how:

There are 2 colors so you can form a gradient, colors are given in a RGB format with Alpha.
If you're not sure how to use the colors, open mspaint, click Colors > Edit Colors and click Define custom colors
on the very right side you can see colors for Red, Green and blue - that's RGB! So simply find a color you want,
and type the RGB numbers in the settings box. If you want to control transparency of the color, after the RGB color,
type a number from 0 (completelly transparent) to 255 (completelly opaque). Dont forget to click Set. Do the same for the second color.

If you want to control the angle of the gradient, in the settings under GradientAngle type something like 45 or 90 or 180 degrees.

It's recommended to make this skin click through after you have finished configuring it. You can later access its menu from the Rainmeter tray icon.

--

NOTICE: If you want another background for your 2nd monitor, right click any skin and select WP7 > Background > AnotherBG > bg.ini